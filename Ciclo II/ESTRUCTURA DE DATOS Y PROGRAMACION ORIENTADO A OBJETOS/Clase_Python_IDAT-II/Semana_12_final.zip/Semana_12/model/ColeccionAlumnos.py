class ColeccionAlumnos:
    def __init__(self):
        self.__listaAlumnos=[]
    
    def agregar(self,objeto):
        self.__listaAlumnos.append(objeto)
    
    def longitud(self):
        return len(self.__listaAlumnos)
    
    def obtener(self,pos):
        return self.__listaAlumnos[pos]
    
    def buscar(self,codigo):
        for i in range(self.longitud()):
            if codigo==self.__listaAlumnos[i].codigo:
                return i
        return -1

    def eliminar(self, pos):
        del(self.__listaAlumnos[pos])
    
    def modificar(self,objeto,pos):
        self.obtener(pos).nombre=objeto.nombre
        self.obtener(pos).nota1=objeto.nota1
        self.obtener(pos).nota2=objeto.nota2




