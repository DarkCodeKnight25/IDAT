from entity.Celular import Celular


class ColeccionCelulares:
    def __init__(self):
        self.__listaCelulares=[]
        self.cargar()
    
    def agregar(self,objeto):
        self.__listaCelulares.append(objeto)
    
    def longitud(self):
        return len(self.__listaCelulares)
    
    def obtener(self,pos):
        return self.__listaCelulares[pos]

    def buscar(self,codigo):
        for i in range(self.longitud()):
            if self.__listaCelulares[i].codigo==codigo:
                return i
        return -1
    
    def eliminar(self,pos):
        del(self.__listaCelulares[pos])
    
    def modificar(self,objReemplazante,pos):
        self.obtener(pos).marca = objReemplazante.marca
        self.obtener(pos).modelo = objReemplazante.modelo
        self.obtener(pos).precio = objReemplazante.precio

    def grabar(self):
        archivo = open("data/Celulares.txt","w",encoding="utf-8")
        for i in range(self.longitud()):
            cadena=self.obtener(i).codigo+";"
            cadena+=self.obtener(i).marca+";"
            cadena+=self.obtener(i).modelo+";"
            cadena+=str(self.obtener(i).precio)+"\n"
            archivo.write(cadena)
        archivo.close()
    
    def cargar(self):
        try:
            archivo = open("data/Celulares.txt","r",encoding="utf-8")
            for linea in archivo.readlines():
                columnas=str(linea).split(";")
                codigo=columnas[0]
                marca=columnas[1]
                modelo=columnas[2]
                precio=float(columnas[3])
                objCelular=Celular(codigo,marca,modelo,precio)
                self.agregar(objCelular)
            archivo.close()
        except IOError:
            print("Error de E/S") 
    





    

