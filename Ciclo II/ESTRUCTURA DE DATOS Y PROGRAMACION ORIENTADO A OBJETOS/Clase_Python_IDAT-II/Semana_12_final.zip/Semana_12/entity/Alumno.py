class Alumno:
    def __init__(self,codigo,nombre,nota1,nota2):
        self.__codigo=codigo
        self.__nombre=nombre
        self.__nota1=nota1
        self.__nota2=nota2

    @property
    def codigo(self):
        return self.__codigo

    @property
    def nombre(self):
        return self.__nombre
    @nombre.setter
    def nombre(self,nombre):
        self.__nombre=nombre
        
    @property
    def nota1(self):
        return self.__nota1
    @nota1.setter
    def nota1(self,nota1):
        self.__nota1=nota1

    @property
    def nota2(self):
        return self.__nota2
    @nota2.setter
    def nota2(self,nota2):
        self.__nota2=nota2


    def calcularPromedio(self):
        return (self.__nota1+self.__nota2)/2
