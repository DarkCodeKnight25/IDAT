from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow,QTableWidgetItem

class frmAlumno(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("view/frmAlumno.ui",self)
        self.show()
        