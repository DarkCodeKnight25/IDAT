import unittest
from entity.Alumno import Alumno

class TestApp(unittest.TestCase):
    def setUp(self):
        self.__obj1 = Alumno(1,"Maritza","Silvera","09123817",27,18,20)

    def testPromedio(self):
        self.assertEqual(self.__obj1.calcularPromedio(),19)
    
    def testCorreo(self):
        self.assertEqual(self.__obj1.generarCorreo(),"maritza.silvera@idat.edu.pe")

    def testIdentificador(self):
        self.assertEqual(self.__obj1.generarIdentificador(),"MAR2709123817")

if __name__ == "__main__":
    unittest.main()
