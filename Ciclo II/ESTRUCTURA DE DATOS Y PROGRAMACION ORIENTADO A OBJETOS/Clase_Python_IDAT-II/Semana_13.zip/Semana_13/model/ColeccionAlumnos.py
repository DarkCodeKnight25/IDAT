from entity.Alumno import Alumno

class ColeccionAlumnos:
    def __init__(self):
        self.__lista = []
        self.cargar()

    def agregar(self,objeto):
        self.__lista.append(objeto)
    
    def longitud(self):
        return len(self.__lista)
    
    def obtener(self,posicion):
        return self.__lista[posicion]
    
    def buscar(self,codigo):
        for i in range(self.longitud()):
            if self.__lista[i].codigo == codigo:
                return i
        return -1
    
    def eliminar(self,posicion):
        del (self.__lista[posicion])

    def modificar(self,objeto,posicion):
        self.obtener(posicion).nombre=objeto.nombre
        self.obtener(posicion).apellido=objeto.apellido
        self.obtener(posicion).dni=objeto.dni
        self.obtener(posicion).edad=objeto.edad
        self.obtener(posicion).nota1=objeto.nota1
        self.obtener(posicion).nota2=objeto.nota2

    def grabar(self):
        archivo = open("data/Alumnos.txt","w",encoding="utf-8")
        for i in range(self.longitud()):
            archivo.write(
                self.obtener(i).codigo + ";" +
                self.obtener(i).nombre + ";" +
                self.obtener(i).apellido + ";" +
                self.obtener(i).dni + ";" +
                str(self.obtener(i).edad) + ";" +
                str(self.obtener(i).nota1) + ";" +
                str(self.obtener(i).nota2) + "\n" 
            )
        archivo.close()

    def cargar(self):
        try:
            archivo = open("data/Alumnos.txt","r",encoding="utf-8")
            for linea in archivo.readlines():
                columnas = str(linea).split(";")
                codigo = columnas[0]
                nombre = columnas[1]
                apellido = columnas[2]
                dni = columnas[3]
                edad = columnas[4]
                nota1 = columnas[5]
                nota2 = columnas[6]
                objAlumno = Alumno(codigo,nombre,apellido,dni,edad,nota1,nota2)
                self.agregar(objAlumno)
            archivo.close()
        except IOError:
            print("Se produjo un error de E/S")



    

    
