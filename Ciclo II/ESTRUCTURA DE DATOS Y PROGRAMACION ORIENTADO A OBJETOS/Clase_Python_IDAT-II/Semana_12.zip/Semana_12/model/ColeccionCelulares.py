class ColeccionCelulares:
    def __init__(self):
        self.__listaCelulares=[]
    
    def agregar(self,objeto):
        self.__listaCelulares.append(objeto)
    
    def longitud(self):
        return len(self.__listaCelulares)
    
    def obtener(self,pos):
        return self.__listaCelulares[pos]

    def buscar(self,codigo):
        for i in range(self.longitud()):
            if self.__listaCelulares[i].codigo==codigo:
                return i
        return -1
    
    def eliminar(self,pos):
        del(self.__listaCelulares[pos])
    
    def modificar(self,objReemplazante,pos):
        self.obtener(pos).marca = objReemplazante.marca
        self.obtener(pos).modelo = objReemplazante.modelo
        self.obtener(pos).precio = objReemplazante.precio

    

