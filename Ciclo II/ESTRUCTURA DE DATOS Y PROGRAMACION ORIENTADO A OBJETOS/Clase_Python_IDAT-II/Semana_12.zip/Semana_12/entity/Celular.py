class Celular:
    def __init__(self,codigo,marca,modelo,precio):
        self.__codigo=codigo
        self.__marca=marca
        self.__modelo=modelo
        self.__precio=precio
    
    @property
    def codigo(self):
        return self.__codigo
    
    @property
    def marca(self):
        return self.__marca
    @marca.setter
    def marca(self,marca):
        self.__marca=marca

    @property
    def modelo(self):
        return self.__modelo
    @modelo.setter
    def modelo(self,modelo):
        self.__modelo=modelo

    @property
    def precio(self):
        return self.__precio
    @precio.setter
    def precio(self,precio):
        self.__precio=precio
    
    
    


