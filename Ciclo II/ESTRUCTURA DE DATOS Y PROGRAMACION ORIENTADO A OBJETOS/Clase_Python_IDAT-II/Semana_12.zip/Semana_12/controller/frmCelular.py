from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem
from model.ColeccionCelulares import ColeccionCelulares
from entity.Celular import Celular

objColeccionCelulares = ColeccionCelulares()

class frmCelular(QMainWindow):
    def __init__(self,parent=None):
        super(frmCelular,self).__init__(parent)
        uic.loadUi("view/frmCelular.ui",self)
        self.btnGrabar.clicked.connect(self.grabar)
        self.tblCelulares.itemClicked.connect(self.mostrar)
        self.btnEliminar.clicked.connect(self.eliminar)
    

    def listar(self):
        self.tblCelulares.setRowCount(objColeccionCelulares.longitud())
        for i in range(objColeccionCelulares.longitud()):
            self.tblCelulares.setItem(i,0,QTableWidgetItem(objColeccionCelulares.obtener(i).codigo))
            self.tblCelulares.setItem(i,1,QTableWidgetItem(objColeccionCelulares.obtener(i).marca))
            self.tblCelulares.setItem(i,2,QTableWidgetItem(objColeccionCelulares.obtener(i).modelo))
            self.tblCelulares.setItem(i,3,QTableWidgetItem(str(objColeccionCelulares.obtener(i).precio)))

    def grabar(self):
        codigo = self.lneCodigo.text()
        marca = self.lneMarca.text()
        modelo = self.lneModelo.text()
        precio = float(self.dsbPrecio.text())
        objCelular = Celular(codigo,marca,modelo,precio)
        posicion = objColeccionCelulares.buscar(codigo)
        if posicion==-1:
            objColeccionCelulares.agregar(objCelular)
        else:
            objColeccionCelulares.modificar(objCelular,posicion)

        self.listar()
        self.limpiar()

    def limpiar(self):
        self.lneCodigo.setText("")
        self.lneMarca.setText("")
        self.lneModelo.setText("")
        self.dsbPrecio.setValue(0)

    def mostrar(self):
        filas = self.tblCelulares.selectedItems()
        indice = filas[0].row()
        codigo = self.tblCelulares.item(indice,0).text()
        marca = self.tblCelulares.item(indice,1).text()
        modelo = self.tblCelulares.item(indice,2).text()
        precio = float(self.tblCelulares.item(indice,3).text())
        self.lneCodigo.setText(codigo)
        self.lneMarca.setText(marca)
        self.lneModelo.setText(modelo)
        self.dsbPrecio.setValue(precio)

    def eliminar(self):
        filas = self.tblCelulares.selectedItems()
        indice = filas[0].row()
        codigo = self.tblCelulares.item(indice,0).text()
        posicion = objColeccionCelulares.buscar(codigo)
        objColeccionCelulares.eliminar(posicion)
        self.tblCelulares.clearContents()
        self.tblCelulares.setRowCount(0)
        self.listar()
        self.limpiar()




