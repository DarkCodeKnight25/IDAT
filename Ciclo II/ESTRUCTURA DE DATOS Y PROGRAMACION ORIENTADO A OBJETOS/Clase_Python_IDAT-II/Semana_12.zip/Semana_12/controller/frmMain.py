from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow
from controller.frmAlumno import frmAlumno
from controller.frmCelular import frmCelular

class frmMain(QMainWindow):
    def __init__(self, parent=None):
        super(frmMain,self).__init__(parent)
        uic.loadUi("view/frmMain.ui",self)
        self.mnuAlumnos.triggered.connect(self.abrirFrmAlumnos)
        self.mnuCelular.triggered.connect(self.abrirFrmCelulares)

    def abrirFrmAlumnos(self):
        ventana = frmAlumno(self)
        ventana.show()

    def abrirFrmCelulares(self):
        ventana = frmCelular(self)
        ventana.show()