from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem
from model.ColeccionAlumnos import ColeccionAlumnos
from entity.Alumno import Alumno

objColeccionAlumnos = ColeccionAlumnos()

class frmAlumno(QMainWindow):
    def __init__(self, parent=None):
        super(frmAlumno,self).__init__(parent)
        uic.loadUi("view/frmAlumno.ui",self)
        self.tblAlumnos.verticalHeader().setVisible(False)
        self.btnGrabar.clicked.connect(self.grabar)
        self.tblAlumnos.itemClicked.connect(self.mostrar)
        self.btnEliminar.clicked.connect(self.eliminar)

    def listar(self):
        self.tblAlumnos.setRowCount(objColeccionAlumnos.longitud())

        for i in range(objColeccionAlumnos.longitud()):
            self.tblAlumnos.setItem(i,0,QTableWidgetItem(objColeccionAlumnos.obtener(i).codigo))
            self.tblAlumnos.setItem(i,1,QTableWidgetItem(objColeccionAlumnos.obtener(i).nombre))
            self.tblAlumnos.setItem(i,2,QTableWidgetItem(str(objColeccionAlumnos.obtener(i).nota1)))
            self.tblAlumnos.setItem(i,3,QTableWidgetItem(str(objColeccionAlumnos.obtener(i).nota2)))
            self.tblAlumnos.setItem(i,4,QTableWidgetItem(str(objColeccionAlumnos.obtener(i).calcularPromedio())))

    def grabar(self):
        codigo = self.lneCodigo.text()
        nombre = self.lneNombre.text()
        nota1 = int(self.spbNota1.text())
        nota2 = int(self.spbNota2.text())
        objAlumno = Alumno(codigo,nombre,nota1,nota2)
        posicion = objColeccionAlumnos.buscar(codigo)
        if posicion==-1:
            objColeccionAlumnos.agregar(objAlumno)
        else:
            objColeccionAlumnos.modificar(objAlumno,posicion)
        self.listar()
        self.limpiar()

    def limpiar(self):
        self.lneCodigo.setText("")
        self.lneNombre.setText("")
        self.spbNota1.setValue(0)
        self.spbNota2.setValue(0)

    def mostrar(self):
        fila = self.tblAlumnos.selectedItems()
        indiceFila = fila[0].row()
        codigo = self.tblAlumnos.item(indiceFila,0).text()
        nombre = self.tblAlumnos.item(indiceFila,1).text()
        nota1 = int(self.tblAlumnos.item(indiceFila,2).text())
        nota2 = int(self.tblAlumnos.item(indiceFila,3).text())
        self.lneCodigo.setText(codigo)
        self.lneNombre.setText(nombre)
        self.spbNota1.setValue(nota1)
        self.spbNota2.setValue(nota2)

    def eliminar(self):
        fila = self.tblAlumnos.selectedItems()
        indiceFila = fila[0].row()
        codigo = self.tblAlumnos.item(indiceFila,0).text()
        posicion = objColeccionAlumnos.buscar(codigo)
        objColeccionAlumnos.eliminar(posicion)
        self.tblAlumnos.clearContents()
        self.tblAlumnos.setRowCount(0)
        self.listar()
        self.limpiar()





