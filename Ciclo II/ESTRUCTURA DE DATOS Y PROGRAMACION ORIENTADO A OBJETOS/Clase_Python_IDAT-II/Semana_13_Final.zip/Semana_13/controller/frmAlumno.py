from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow,QTableWidgetItem

class frmAlumno(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("view/frmAlumno.ui",self)
        self.btnNuevo.clicked.connect(self.nuevo)
        self.btnGrabar.clicked.connect(self.grabar)
        self.show()
        self.deshabilitarControles(True)
        self.habilitarBotones(True)

    def nuevo(self):
        self.habilitarBotones(False)
        self.deshabilitarControles(False)
        self.lneCodigo.setFocus(True)
        
    def grabar(self):
        self.habilitarBotones(True)
        self.deshabilitarControles(True)
 
    def habilitarBotones(self, estado):
        self.btnNuevo.setEnabled(estado)
        self.btnGrabar.setEnabled(not estado)
        self.btnEliminar.setEnabled(not estado)
        self.btnEditar.setEnabled(not estado)

    def deshabilitarControles(self, estado):
        self.lneCodigo.setReadOnly(estado)
        self.lneNombre.setReadOnly(estado)
        self.spbNota1.setReadOnly(estado)
        self.spbNota2.setReadOnly(estado)
