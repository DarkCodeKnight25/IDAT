import sys
from PyQt5.QtWidgets import QApplication
from controller.frmAlumno import frmAlumno

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = frmAlumno()
    app.exec_()
