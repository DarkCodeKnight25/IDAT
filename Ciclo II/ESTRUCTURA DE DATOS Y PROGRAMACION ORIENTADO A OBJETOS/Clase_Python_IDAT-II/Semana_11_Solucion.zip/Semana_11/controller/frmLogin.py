from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow
from controller.frmMain import frmMain

class frmLogin(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("view/frmLogin.ui",self)
        self.btnAceptar.clicked.connect(self.ingresar)
        self.btnCancelar.clicked.connect(self.close)
        self.show()
    
    def ingresar(self):
        usuario = self.lneUsuario.text()
        clave = self.lneClave.text()
        
        if usuario=="admin" and clave=="1234":
            self.close()
            ventana = frmMain(self)
            ventana.show()


