from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow

class frmAlumno(QMainWindow):
    def __init__(self, parent=None):
        super(frmAlumno,self).__init__(parent)
        uic.loadUi("view/frmAlumno.ui",self)
