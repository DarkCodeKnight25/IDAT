from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow
from controller.frmAlumno import frmAlumno

class frmMain(QMainWindow):
    def __init__(self, parent=None):
        super(frmMain,self).__init__(parent)
        uic.loadUi("view/frmMain.ui",self)
        self.mnuAlumnos.triggered.connect(self.abrirFrmAlumnos)

    def abrirFrmAlumnos(self):
        ventana = frmAlumno(self)
        ventana.show()
