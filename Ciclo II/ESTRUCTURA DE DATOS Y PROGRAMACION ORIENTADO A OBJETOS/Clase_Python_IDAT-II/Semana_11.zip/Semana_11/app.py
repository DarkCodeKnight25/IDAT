import sys
from PyQt5.QtWidgets import QApplication
from controller.frmLogin import frmLogin

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ventana = frmLogin()
    app.exec_()

