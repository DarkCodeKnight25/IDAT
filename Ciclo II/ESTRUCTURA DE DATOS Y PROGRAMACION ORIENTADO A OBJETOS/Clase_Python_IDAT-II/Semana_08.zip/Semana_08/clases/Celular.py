class Celular:
    def __init__(self,numero,usuario,segundosConsumidos,precioSegundo):
        self.__numero=numero
        self.__usuario=usuario
        self.__segundosConsumidos=segundosConsumidos
        self.__precioSegundo=precioSegundo

    @property
    def numero(self):
        return self.__numero
    @numero.setter
    def numero(self,numero):
        self.__numero=numero

    @property
    def usuario(self):
        return self.__usuario
    @usuario.setter
    def usuario(self,usuario):
        self.__usuario=usuario

    @property
    def segundosConsumidos(self):
        return self.__segundosConsumidos
    @segundosConsumidos.setter
    def segundosConsumidos(self,segundosConsumidos):
        self.__segundosConsumidos=segundosConsumidos

    @property
    def precioSegundo(self):
        return self.__precioSegundo
    @precioSegundo.setter
    def precioSegundo(self,precioSegundo):
        self.__precioSegundo=precioSegundo

    def calcularCostoConsumo(self):
        return self.__segundosConsumidos*self.__precioSegundo
    
    def calcularIGV(self):
        return self.calcularCostoConsumo()*18/100

    def calcularImportePagar(self):
        return self.calcularCostoConsumo() + self.calcularIGV()


