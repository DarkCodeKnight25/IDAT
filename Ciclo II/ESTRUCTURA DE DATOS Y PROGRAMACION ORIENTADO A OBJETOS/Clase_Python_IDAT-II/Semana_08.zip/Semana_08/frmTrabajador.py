import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication
from clases.Trabajador import Trabajador

class frmTrabajador(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        uic.loadUi("gui/frmTrabajador.ui",self)
        self.btnAceptar.clicked.connect(self.mostrarDatos)
    
    def mostrarDatos(self):
        objTrabajador = Trabajador(1001,"José",20,30)
        salida = "Código:\t" + str(objTrabajador.codigo)
        salida += "\nNombre:\t" + str(objTrabajador.nombre)
        salida += "\nHoras:\t" + str(objTrabajador.horas)
        salida += "\nTarifa:\t" + str(objTrabajador.tarifa)
        salida += "\nSueldo bruto:\t" + str(objTrabajador.calcularSueldoBruto())
        salida += "\nDescuento:\t" + str(objTrabajador.calcularDescuento())
        salida += "\nSueldo neto:\t" + str(objTrabajador.calcularSueldoNeto())

        self.lblSalida.setText(salida)
                
if __name__ == '__main__':
    app = QApplication(sys.argv)
    gui = frmTrabajador()
    gui.show()
    sys.exit(app.exec_())
