import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QMainWindow, QApplication
from clases.Celular import Celular

class frmCelular(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        uic.loadUi("gui/frmCelular.ui",self)
        self.btnAceptar.clicked.connect(self.mostrarDatos)
    
    def mostrarDatos(self):
        numero = self.lneNumero.text()
        usuario = self.lneUsuario.text()
        segundos = int(self.spbSegundos.text())
        precio = float(self.dsbPrecio.text())
        objCelular = Celular(numero,usuario,segundos,precio)
        self.listar(objCelular)
        objCelular.segundosConsumidos += 20
        #objCelular.segundosConsumidos = objCelular.segundosConsumidos + 20
        objCelular.precioSegundo -= objCelular.precioSegundo*5/100 
        #objCelular.precioSegundo = objCelular.precioSegundo - objCelular.precioSegundo*5/100 
        self.listar(objCelular)

    def listar(self, objeto): 
        salida = "Número: \t" + objeto.numero
        salida += "\nUsuario: \t" + objeto.usuario
        salida += "\nSegundos consumidos: \t" + str(objeto.segundosConsumidos)
        salida += "\nPrecio por segundo: \t" + str(objeto.precioSegundo)
        salida += "\nCosto por consumo: \t" + str(objeto.calcularCostoConsumo())
        salida += "\nIGV: \t" + str(objeto.calcularIGV())
        salida += "\nImporte a pagar: \t" + str(objeto.calcularImportePagar())
        salida += "\n______________________________________________"
        self.txtSalida.append(salida)
                
if __name__ == '__main__':
    app = QApplication(sys.argv)
    gui = frmCelular()
    gui.show()
    sys.exit(app.exec_())
