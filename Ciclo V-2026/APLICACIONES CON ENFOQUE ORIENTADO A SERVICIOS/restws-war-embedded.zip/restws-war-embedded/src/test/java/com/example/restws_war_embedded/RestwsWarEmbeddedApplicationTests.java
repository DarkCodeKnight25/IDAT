package com.example.restws_war_embedded;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestwsWarEmbeddedApplicationTests {

	@Test
	void contextLoads() {
	}

}
