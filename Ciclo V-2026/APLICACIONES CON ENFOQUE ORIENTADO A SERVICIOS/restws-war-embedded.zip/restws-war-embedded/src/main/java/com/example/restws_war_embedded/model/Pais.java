package com.example.restws_war_embedded.model;

public class Pais {
    private int id; //ID: 1
    private String nombre; // NOMBRE: PERU
    private String capital; //CAPITAL: LIMA
    private int poblacion; // POBLACION: 30 000 000
    private String continente; //CONTINENTE: AMERICA

    public Pais() {}

    public Pais(int id, String nombre, String capital, int poblacion, String continente) {
        this.id = id;
        this.nombre = nombre;
        this.capital = capital;
        this.poblacion = poblacion;
        this.continente = continente;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getCapital() { return capital; }
    public void setCapital(String capital) { this.capital = capital; }
    public int getPoblacion() { return poblacion; }
    public void setPoblacion(int poblacion) { this.poblacion = poblacion; }
    public String getContinente() { return continente; }
    public void setContinente(String continente) { this.continente = continente; }
}
