package com.example.restws_war_embedded.controller;

import com.example.restws_war_embedded.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/paises")
public class PaisController {

    private List<Pais> paises = new ArrayList<>();

    public PaisController() {
        paises.add(new Pais(1, "Perú", "Lima", 33000000, "América"));
        paises.add(new Pais(2, "Chile", "Santiago", 19000000, "América"));
        paises.add(new Pais(3, "España", "Madrid", 47000000, "Europa"));
    }

    // GET todos los países
    @GetMapping
    public List<Pais> getAllPaises() { return paises; }

    // GET país por ID
    @GetMapping("/{id}")
    public ResponseEntity<Pais> getPaisById(@PathVariable int id) {
        return paises.stream()
                     .filter(p -> p.getId() == id)
                     .findFirst()
                     .map(ResponseEntity::ok)
                     .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    // POST nuevo país
    @PostMapping
    public ResponseEntity<Pais> createPais(@RequestBody Pais pais) {
        paises.add(pais);
        return ResponseEntity.status(HttpStatus.CREATED).body(pais);
    }

    // PUT actualizar país
    @PutMapping("/{id}") //api/actualizarpais/1 json:datos del pais actualizado
    public ResponseEntity<Pais> updatePais(@PathVariable int id, @RequestBody Pais paisActualizado) {
        for (Pais p : paises) {
            if (p.getId() == id) {
                p.setNombre(paisActualizado.getNombre());
                p.setCapital(paisActualizado.getCapital());
                p.setPoblacion(paisActualizado.getPoblacion());
                p.setContinente(paisActualizado.getContinente());
                return ResponseEntity.ok(p);
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // DELETE país
    @DeleteMapping("/{id}") //api/eliminarpais/1
    public ResponseEntity<Void> deletePais(@PathVariable int id) {
        paises.removeIf(p -> p.getId() == id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
