package com.example.restws_war_embedded;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestwsWarEmbeddedApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestwsWarEmbeddedApplication.class, args);
	}

}
