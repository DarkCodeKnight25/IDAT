package com.example.soapws;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.DOMImplementation;

@Endpoint
public class CountryEndpoint {

    private static final String NAMESPACE = "http://example.com/soapws";
    private final CountryRepository repository;

    public CountryEndpoint(CountryRepository repository) {
        this.repository = repository;
    }

    @PayloadRoot(namespace = NAMESPACE, localPart = "getCountryRequest")
    @ResponsePayload
    public Element getCountry(@RequestPayload Element request) throws Exception {
        // Leer <name> (soporta con o sin namespace)
        String name = null;
        if (request.getElementsByTagNameNS(NAMESPACE, "name").getLength() > 0) {
            name = request.getElementsByTagNameNS(NAMESPACE, "name").item(0).getTextContent();
        } else if (request.getElementsByTagName("name").getLength() > 0) {
            name = request.getElementsByTagName("name").item(0).getTextContent();
        }

        Country country = repository.findCountry(name);

        // Crear documento XML usando las APIs del JDK (DOMImplementation)
        DOMImplementationRegistry registry = DOMImplementationRegistry.newInstance();
        // Obtener implementación para XML
        DOMImplementation impl = registry.getDOMImplementation("XML 1.0");
        Document doc = impl.createDocument(NAMESPACE, "getCountryResponse", null);

        Element responseEl = doc.getDocumentElement(); // ya es <getCountryResponse>
        Element countryEl = doc.createElementNS(NAMESPACE, "country");

        Element nameEl = doc.createElementNS(NAMESPACE, "name");
        nameEl.setTextContent(country != null ? country.getName() : "");
        Element capitalEl = doc.createElementNS(NAMESPACE, "capital");
        capitalEl.setTextContent(country != null ? country.getCapital() : "");
        Element populationEl = doc.createElementNS(NAMESPACE, "population");
        populationEl.setTextContent(country != null ? String.valueOf(country.getPopulation()) : "0");
        Element currencyEl = doc.createElementNS(NAMESPACE, "currency");
        currencyEl.setTextContent(country != null ? country.getCurrency() : "");

        countryEl.appendChild(nameEl);
        countryEl.appendChild(capitalEl);
        countryEl.appendChild(populationEl);
        countryEl.appendChild(currencyEl);

        responseEl.appendChild(countryEl);
        return responseEl;
    }
}
