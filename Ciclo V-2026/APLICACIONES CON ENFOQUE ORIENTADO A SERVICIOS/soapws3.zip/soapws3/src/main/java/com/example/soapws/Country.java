package com.example.soapws;

public class Country {
    private String name;
    private String capital;
    private int population;
    private String currency;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCapital() { return capital; }
    public void setCapital(String capital) { this.capital = capital; }
    public int getPopulation() { return population; }
    public void setPopulation(int population) { this.population = population; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
}
