package com.example.soapws;

import org.springframework.stereotype.Component;
import java.util.HashMap;
import java.util.Map;

@Component
public class CountryRepository {

    private static final Map<String, Country> countries = new HashMap<>();

    public CountryRepository() {
        Country spain = new Country();
        spain.setName("Spain");
        spain.setCapital("Madrid");
        spain.setPopulation(46704314);
        spain.setCurrency("EUR");
        countries.put("Spain", spain);

        Country peru = new Country();
        peru.setName("Peru");
        peru.setCapital("Lima");
        peru.setPopulation(34000000);
        peru.setCurrency("PEN");
        countries.put("Peru", peru);
    }

    public Country findCountry(String name) {
        return countries.get(name);
    }
}
