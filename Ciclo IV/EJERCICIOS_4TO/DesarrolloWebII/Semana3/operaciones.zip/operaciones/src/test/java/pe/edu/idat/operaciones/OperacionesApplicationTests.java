package pe.edu.idat.operaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
