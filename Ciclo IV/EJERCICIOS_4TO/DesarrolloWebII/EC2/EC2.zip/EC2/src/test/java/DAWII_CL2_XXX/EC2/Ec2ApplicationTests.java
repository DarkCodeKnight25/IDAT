package DAWII_CL2_XXX.EC2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ec2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
