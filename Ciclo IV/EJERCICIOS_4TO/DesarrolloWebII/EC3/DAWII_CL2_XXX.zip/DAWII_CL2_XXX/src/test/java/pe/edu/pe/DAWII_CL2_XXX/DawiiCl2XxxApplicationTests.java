package pe.edu.pe.DAWII_CL2_XXX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawiiCl2XxxApplicationTests {

	@Test
	void contextLoads() {
	}

}
