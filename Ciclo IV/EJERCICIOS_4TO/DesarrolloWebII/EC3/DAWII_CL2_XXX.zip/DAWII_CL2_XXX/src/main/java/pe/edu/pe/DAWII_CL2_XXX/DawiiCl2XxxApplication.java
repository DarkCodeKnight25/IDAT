package pe.edu.pe.DAWII_CL2_XXX;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawiiCl2XxxApplication {

	public static void main(String[] args) {
		SpringApplication.run(DawiiCl2XxxApplication.class, args);
	}

}
