package pe.edu.idat.appWebSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppWebSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppWebSpringApplication.class, args);
	}

}
